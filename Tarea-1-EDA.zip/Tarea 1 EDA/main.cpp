#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <chrono>
#include "sort.hpp"

// Implement Sequential Search (AS)
bool sequentialSearch(const std::vector<std::string>& dictionary, const std::string& query) {
    for (const auto& word : dictionary) {
        if (word == query) {
            return true;
        }
    }
    return false;
}

// Implement Binary Search (ABB)
bool binarySearch(const std::vector<std::string>& dictionary, const std::string& query) {
    int left = 0;
    int right = dictionary.size() - 1;

    while (left <= right) {
        int mid = left + (right - left) / 2;

        if (dictionary[mid] == query) {
            return true;
        }
        if (dictionary[mid] < query) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return false;
}

// Function to load a dictionary from a file
std::vector<std::string> loadDictionary(const std::string& filename) {
    std::vector<std::string> dictionary;
    std::ifstream file(filename);
    std::string word;

    if (!file.is_open()) {
        std::cerr << "Could not open the file " << filename << std::endl;
        return dictionary;
    }

    while (file >> word) {
        dictionary.push_back(word);
    }

    file.close();
    return dictionary;
}

// Function to load queries from a file
std::vector<std::string> loadQueries(const std::string& filename) {
    std::vector<std::string> queries;
    std::ifstream file(filename);
    std::string query;

    if (!file.is_open()) {
        std::cerr << "Could not open the file " << filename << std::endl;
        return queries;
    }

    while (file >> query) {
        queries.push_back(query);
    }

    file.close();
    return queries;
}

// Function to perform the experiments for a given dictionary size
void runExperiment(const std::string& dictionaryFile, const std::vector<std::string>& queries) {
    std::vector<std::string> dictionary = loadDictionary(dictionaryFile);

    if (dictionary.empty()) {
        std::cerr << "Failed to load dictionary from " << dictionaryFile << std::endl;
        return;
    }

    int foundSequential = 0;
    int foundBinary = 0;

    // Measure time for Sequential Search
    auto startSequential = std::chrono::high_resolution_clock::now();
    for (const auto& query : queries) {
        if (sequentialSearch(dictionary, query)) {
            foundSequential++;
        }
    }
    auto endSequential = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> durationSequential = endSequential - startSequential;

    // Sort the dictionary for Binary Search
    auto startSort = std::chrono::high_resolution_clock::now();
    sort::quickSort(dictionary.data(), dictionary.size());
    auto endSort = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> durationSort = endSort - startSort;

    // Measure time for Binary Search
    auto startBinary = std::chrono::high_resolution_clock::now();
    for (const auto& query : queries) {
        if (binarySearch(dictionary, query)) {
            foundBinary++;
        }
    }
    auto endBinary = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> durationBinary = endBinary - startBinary;

    // Output results, i'll use these to gather data and create tables + graphs in the report
    std::cout << "Results for dictionary size: " << dictionary.size() << std::endl;
    std::cout << "Sequential Search found: " << foundSequential << " terms in " << durationSequential.count() << " seconds." << std::endl;
    std::cout << "Sorting took: " << durationSort.count() << " seconds." << std::endl;
    std::cout << "Binary Search found: " << foundBinary << " terms in " << durationBinary.count() << " seconds." << std::endl;
    std::cout << "Binary Search + Sort total time: " << (durationBinary.count() + durationSort.count()) << " seconds." << std::endl;
    std::cout << "---------------------------------------------------------" << std::endl;
}

int main() {
    // Load the queries
    std::string queriesFile = "t1_eda/Nc.txt"; // Path to file, if you're having issues with directory modify this line
    std::vector<std::string> queries = loadQueries(queriesFile);

    if (queries.empty()) {
        std::cerr << "Failed to load queries from " << queriesFile << std::endl;
        return 1;
    }

    // Run experiments for each dictionary size
    runExperiment("t1_eda/D10000.txt", queries);
    runExperiment("t1_eda/D50000.txt", queries);
    runExperiment("t1_eda/D100000.txt", queries);
    runExperiment("t1_eda/D200000.txt", queries);
    runExperiment("t1_eda/D400000.txt", queries);

    return 0;
}
